Core/Src/resistor_calculator.o: ../Core/Src/resistor_calculator.c \
 ../Core/Inc/resistor_calculator.h
../Core/Inc/resistor_calculator.h:
