/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "resistor_calculator.h"
#include "resistor_gui.h"
#include <string.h>
#include <stdio.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
SPI_HandleTypeDef hspi1;

/* USER CODE BEGIN PV */
typedef struct {
    GPIO_TypeDef* port;
    uint16_t pin;
    ResistorColor color_val;
    bool is_action_btn;
    uint8_t action_id; // 1=Calculate, 2=Clear
    uint32_t last_debounce_time;
    GPIO_PinState last_stable_state;
    GPIO_PinState current_reading;
} Button_t;

#define NUM_BUTTONS 14
Button_t buttons[NUM_BUTTONS] = {
    {BLACK_GPIO_Port,     BLACK_Pin,     COLOR_BLACK,  false, 0, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // BLACK
    {BROWN_GPIO_Port,     BROWN_Pin,     COLOR_BROWN,  false, 0, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // BROWN
    {RED_GPIO_Port,       RED_Pin,       COLOR_RED,    false, 0, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // RED
    {ORANGE_GPIO_Port,    ORANGE_Pin,    COLOR_ORANGE, false, 0, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // ORANGE
    {YELLOW_GPIO_Port,    YELLOW_Pin,    COLOR_YELLOW, false, 0, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // YELLOW
    {GREEN_GPIO_Port,     GREEN_Pin,     COLOR_GREEN,  false, 0, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // GREEN
    {BLUE_GPIO_Port,      BLUE_Pin,      COLOR_BLUE,   false, 0, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // BLUE
    {VIOLET_GPIO_Port,    VIOLET_Pin,    COLOR_VIOLET, false, 0, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // VIOLET
    {GRAY_GPIO_Port,      GRAY_Pin,      COLOR_GRAY,   false, 0, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // GRAY
    {WHITE_GPIO_Port,     WHITE_Pin,     COLOR_WHITE,  false, 0, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // WHITE
    {GOLD_GPIO_Port,      GOLD_Pin,      COLOR_GOLD,   false, 0, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // GOLD
    {SILVER_GPIO_Port,    SILVER_Pin,    COLOR_SILVER, false, 0, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // SILVER
    {CALCULATE_GPIO_Port, CALCULATE_Pin, COLOR_NONE,   true,  1, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // CALCULATE
    {CLEAR_GPIO_Port,     CLEAR_Pin,     COLOR_NONE,   true,  2, 0, GPIO_PIN_SET, GPIO_PIN_SET}, // CLEAR
};

ResistorColor entered_colors[6] = { COLOR_NONE, COLOR_NONE, COLOR_NONE, COLOR_NONE, COLOR_NONE, COLOR_NONE };
int color_count = 0;

uint8_t current_mode = 0; // 0 = Color-to-Value, 1 = Value-to-Color
char value_input_buffer[16] = "";
int value_input_len = 0;
bool value_result_showing = false;
int current_result_bands = 0;

uint8_t system_state = 0; // 0 = Menu, 1 = Active Mode
uint8_t menu_selection = 0; // 0 = Color Mode, 1 = Value Mode

// Press-time tracking for Action buttons to support long presses
uint32_t calc_press_start = 0;
bool calc_long_press_handled = false;
uint32_t clear_press_start = 0;
bool clear_long_press_handled = false;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_SPI1_Init(void);
/* USER CODE BEGIN PFP */
void ScanButtons(void);
void HandleButtonPress(Button_t* btn);
void HandleButtonShortPress(int btn_idx);
void HandleButtonLongPress(int btn_idx);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
#define DEBOUNCE_DELAY 50 // ms

static char GetButtonChar(Button_t* btn) {
    if (btn->port == BLACK_GPIO_Port && btn->pin == BLACK_Pin) return '0';
    if (btn->port == BROWN_GPIO_Port && btn->pin == BROWN_Pin) return '1';
    if (btn->port == RED_GPIO_Port && btn->pin == RED_Pin) return '2';
    if (btn->port == ORANGE_GPIO_Port && btn->pin == ORANGE_Pin) return '3';
    if (btn->port == YELLOW_GPIO_Port && btn->pin == YELLOW_Pin) return '4';
    if (btn->port == GREEN_GPIO_Port && btn->pin == GREEN_Pin) return '5';
    if (btn->port == BLUE_GPIO_Port && btn->pin == BLUE_Pin) return '6';
    if (btn->port == VIOLET_GPIO_Port && btn->pin == VIOLET_Pin) return '7';
    if (btn->port == GRAY_GPIO_Port && btn->pin == GRAY_Pin) return '8';
    if (btn->port == WHITE_GPIO_Port && btn->pin == WHITE_Pin) return '9';
    if (btn->port == GOLD_GPIO_Port && btn->pin == GOLD_Pin) return 'R';
    if (btn->port == SILVER_GPIO_Port && btn->pin == SILVER_Pin) return 'k';
    return '\0';
}

void ScanButtons(void) {
    uint32_t now = HAL_GetTick();

    for (int i = 0; i < NUM_BUTTONS; i++) {
        GPIO_PinState reading = HAL_GPIO_ReadPin(buttons[i].port, buttons[i].pin);

        if (reading != buttons[i].current_reading) {
            buttons[i].last_debounce_time = now;
            buttons[i].current_reading = reading;
        }

        if ((now - buttons[i].last_debounce_time) > DEBOUNCE_DELAY) {
            if (i == 12) { // CALCULATE / OK
                if (reading == GPIO_PIN_RESET) {
                    if (calc_press_start == 0) {
                        calc_press_start = now;
                        calc_long_press_handled = false;
                    } else if (!calc_long_press_handled && (now - calc_press_start > 800)) {
                        calc_long_press_handled = true;
                        HandleButtonLongPress(12);
                    }
                } else { // GPIO_PIN_SET
                    if (calc_press_start != 0) {
                        uint32_t duration = now - calc_press_start;
                        calc_press_start = 0;
                        if (duration > DEBOUNCE_DELAY && !calc_long_press_handled) {
                            HandleButtonShortPress(12);
                        }
                    }
                }
            }
            else if (i == 13) { // CLEAR / SCROLL / M
                if (reading == GPIO_PIN_RESET) {
                    if (clear_press_start == 0) {
                        clear_press_start = now;
                        clear_long_press_handled = false;
                    } else if (!clear_long_press_handled && (now - clear_press_start > 800)) {
                        clear_long_press_handled = true;
                        HandleButtonLongPress(13);
                    }
                } else { // GPIO_PIN_SET
                    if (clear_press_start != 0) {
                        uint32_t duration = now - clear_press_start;
                        clear_press_start = 0;
                        if (duration > DEBOUNCE_DELAY && !clear_long_press_handled) {
                            HandleButtonShortPress(13);
                        }
                    }
                }
            }
            else { // Digits 0 to 11
                if (reading != buttons[i].last_stable_state) {
                    buttons[i].last_stable_state = reading;

                    if (reading == GPIO_PIN_RESET) {
                        HandleButtonPress(&buttons[i]);
                    }
                }
            }
        }
    }
}

void HandleButtonPress(Button_t* btn) {
    if (system_state == 0) {
        // Ignore color/digit button presses in Menu Mode
        return;
    }

    if (btn->is_action_btn) {
        // Action buttons are handled by Short/Long press handlers
        return;
    }

    if (current_mode == 0) {
        // Color-to-Value Mode
        if (color_count >= 6) {
            GUI_DrawError("Max Bands (6)", "Press Calc or Clear");
            return;
        }
        entered_colors[color_count++] = btn->color_val;

        // Redraw resistor body with the new band
        GUI_DrawResistor(entered_colors, color_count);

        // Display current entered bands list at the bottom
        char list_buf[48] = "";
        for (int i = 0; i < color_count; i++) {
            strcat(list_buf, GetColorAbbreviation(entered_colors[i]));
            if (i < color_count - 1) {
                strcat(list_buf, " ");
            }
        }
        GUI_DrawStatus(list_buf);
    } else {
        // Value-to-Color Mode
        if (value_result_showing) {
            // Clear result and start new input
            value_input_buffer[0] = '\0';
            value_input_len = 0;
            value_result_showing = false;
            GUI_DrawResistor(NULL, 0);
        }

        if (value_input_len < 15) {
            char ch = GetButtonChar(btn);
            if (ch != '\0') {
                value_input_buffer[value_input_len++] = ch;
                value_input_buffer[value_input_len] = '\0';
                GUI_DrawStatus(value_input_buffer);
            }
        }
    }
}

void HandleButtonShortPress(int btn_idx) {
    if (system_state == 0) {
        // Menu Mode
        if (btn_idx == 12) { // CALCULATE / OK
            // Select highlighted mode
            GUI_DrawTransition(menu_selection);
            HAL_Delay(1500);
            ST7735_FillScreen(BG_COLOR);

            // Switch to Active Mode
            current_mode = menu_selection;
            system_state = 1;

            // Reset and initialize UI for the selected mode
            color_count = 0;
            for (int i = 0; i < 6; i++) entered_colors[i] = COLOR_NONE;
            value_input_buffer[0] = '\0';
            value_input_len = 0;
            value_result_showing = false;
            current_result_bands = 0;

            GUI_DrawResistor(NULL, 0);
            if (current_mode == 0) {
                GUI_DrawStatus("Select Colors...");
            } else {
                GUI_DrawStatus("Enter Value...");
            }
        } else if (btn_idx == 13) { // CLEAR / SCROLL
            // Toggle menu selection
            menu_selection = (menu_selection == 0) ? 1 : 0;
            GUI_DrawMenu(menu_selection);
        }
        return;
    }

    // Active Mode
    if (current_mode == 0) {
        // Mode 0: Color-to-Value
        if (btn_idx == 12) { // CALCULATE
            if (color_count < 3) {
                GUI_DrawError("Min 3 Bands", "Enter more bands");
                return;
            }
            char err_msg[32];
            if (!ValidateColorSequence(entered_colors, color_count, err_msg, sizeof(err_msg))) {
                GUI_DrawError("Invalid Code", err_msg);
                return;
            }
            ResistorResult result;
            if (CalculateResistor(entered_colors, color_count, &result)) {
                char val_str[32];
                char tol_str[32];
                FormatResistance(&result, val_str, sizeof(val_str), tol_str, sizeof(tol_str));
                GUI_DrawResult(val_str, tol_str);
            } else {
                GUI_DrawError("Calc Error", "Math failed");
            }
        } else if (btn_idx == 13) { // CLEAR
            if (color_count > 0) {
                color_count = 0;
                for (int i = 0; i < 6; i++) entered_colors[i] = COLOR_NONE;
                GUI_DrawResistor(NULL, 0);
                GUI_DrawStatus("Select Colors...");
            } else {
                // Empty, toggle to Mode 1 (Value-to-Color) with transition screen
                GUI_DrawTransition(1);
                HAL_Delay(1500);
                ST7735_FillScreen(BG_COLOR);

                current_mode = 1;
                value_input_buffer[0] = '\0';
                value_input_len = 0;
                value_result_showing = false;
                current_result_bands = 0;
                GUI_DrawResistor(NULL, 0);
                GUI_DrawStatus("Enter Value...");
            }
        }
    } else {
        // Mode 1: Value-to-Color
        if (btn_idx == 12) { // CALCULATE / OK
            if (value_input_len == 0) {
                GUI_DrawError("No Value", "Enter e.g. 4k7");
                return;
            }
            double val;
            if (ParseResistanceString(value_input_buffer, &val)) {
                ResistorColor colors[6];
                int count = 0;

                int target_prefer = 0; // auto-detect
                if (value_result_showing) {
                    target_prefer = (current_result_bands == 4) ? 5 : 4;
                }

                if (ValueToColors(val, colors, &count, target_prefer)) {
                    // Update graphic
                    GUI_DrawResistor(colors, count);

                    // Format values using standard library helper
                    ResistorResult result;
                    result.value = val;
                    result.tolerance = (count == 5) ? 1.0f : 5.0f; // 1% for 5-band, 5% for 4-band
                    result.has_tolerance = true;
                    result.has_tempco = false;
                    result.tempco = 0;

                    char val_str[32];
                    char tol_str[32];
                    FormatResistance(&result, val_str, sizeof(val_str), tol_str, sizeof(tol_str));

                    // Format colors abbreviation list
                    char colors_str[64] = "";
                    for (int i = 0; i < count; i++) {
                        strcat(colors_str, GetColorShortName(colors[i]));
                        if (i < count - 1) {
                            strcat(colors_str, " ");
                        }
                    }

                    GUI_DrawResult(val_str, colors_str);
                    value_result_showing = true;
                    current_result_bands = count;
                } else {
                    if (value_result_showing) {
                        // If it failed to switch (e.g. 121 ohms has no 4-band version), just keep showing the current one
                        // or do nothing.
                    } else {
                        GUI_DrawError("Out of Range", "Value unsupported");
                    }
                }
            } else {
                GUI_DrawError("Invalid Value", "Format: 4.7k, 4k7");
            }
        } else if (btn_idx == 13) { // CLEAR / SCROLL / M
            if (value_result_showing) {
                // Clear result, empty buffer and toggle back to Mode 0 (Color-to-Value) with transition screen
                GUI_DrawTransition(0);
                HAL_Delay(1500);
                ST7735_FillScreen(BG_COLOR);

                value_result_showing = false;
                current_result_bands = 0;
                value_input_buffer[0] = '\0';
                value_input_len = 0;
                current_mode = 0;
                color_count = 0;
                for (int i = 0; i < 6; i++) entered_colors[i] = COLOR_NONE;
                GUI_DrawResistor(NULL, 0);
                GUI_DrawStatus("Select Colors...");
            } else {
                if (value_input_len > 0) {
                    // Append 'M'
                    if (value_input_len < 15) {
                        value_input_buffer[value_input_len++] = 'M';
                        value_input_buffer[value_input_len] = '\0';
                        GUI_DrawStatus(value_input_buffer);
                    }
                } else {
                    // Empty, toggle to Mode 0 (Color-to-Value) with transition screen
                    GUI_DrawTransition(0);
                    HAL_Delay(1500);
                    ST7735_FillScreen(BG_COLOR);

                    current_mode = 0;
                    color_count = 0;
                    for (int i = 0; i < 6; i++) entered_colors[i] = COLOR_NONE;
                    GUI_DrawResistor(NULL, 0);
                    GUI_DrawStatus("Select Colors...");
                }
            }
        }
    }
}

void HandleButtonLongPress(int btn_idx) {
    if (system_state == 0) {
        // Ignore long presses in Menu Mode
        return;
    }

    if (btn_idx == 12) { // CALCULATE / OK
        if (current_mode == 1) {
            // Clear input buffer in Value-to-Color Mode
            value_input_buffer[0] = '\0';
            value_input_len = 0;
            value_result_showing = false;
            current_result_bands = 0;
            GUI_DrawResistor(NULL, 0);
            GUI_DrawStatus("Enter Value...");
        }
    } else if (btn_idx == 13) { // CLEAR / SCROLL
        // Toggle system mode immediately with transition screen
        if (current_mode == 0) {
            GUI_DrawTransition(1);
            HAL_Delay(1500);
            ST7735_FillScreen(BG_COLOR);

            current_mode = 1;
            value_input_buffer[0] = '\0';
            value_input_len = 0;
            value_result_showing = false;
            current_result_bands = 0;
            GUI_DrawResistor(NULL, 0);
            GUI_DrawStatus("Enter Value...");
        } else {
            GUI_DrawTransition(0);
            HAL_Delay(1500);
            ST7735_FillScreen(BG_COLOR);

            current_mode = 0;
            color_count = 0;
            for (int i = 0; i < 6; i++) entered_colors[i] = COLOR_NONE;
            GUI_DrawResistor(NULL, 0);
            GUI_DrawStatus("Select Colors...");
        }
    }
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_SPI1_Init();
  /* USER CODE BEGIN 2 */
  GUI_Init();
  system_state = 0;
  menu_selection = 0;
  GUI_DrawMenu(menu_selection);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    ScanButtons();
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_1LINE;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_16;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(CS_GPIO_Port, CS_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, A0_Pin|RESET_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pins : BLACK_Pin BROWN_Pin RED_Pin ORANGE_Pin
                           GREEN_Pin BLUE_Pin VIOLET_Pin GRAY_Pin
                           WHITE_Pin */
  GPIO_InitStruct.Pin = BLACK_Pin|BROWN_Pin|RED_Pin|ORANGE_Pin
                          |GREEN_Pin|BLUE_Pin|VIOLET_Pin|GRAY_Pin
                          |WHITE_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : CS_Pin */
  GPIO_InitStruct.Pin = CS_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(CS_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : YELLOW_Pin */
  GPIO_InitStruct.Pin = YELLOW_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(YELLOW_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : GOLD_Pin */
  GPIO_InitStruct.Pin = GOLD_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  HAL_GPIO_Init(GOLD_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : A0_Pin RESET_Pin */
  GPIO_InitStruct.Pin = A0_Pin|RESET_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pins : CALCULATE_Pin CLEAR_Pin SILVER_Pin */
  GPIO_InitStruct.Pin = CALCULATE_Pin|CLEAR_Pin|SILVER_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  // Ensure all buttons configured as NOPULL have internal pull-ups enabled
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLUP;

  GPIO_InitStruct.Pin = YELLOW_Pin;
  HAL_GPIO_Init(YELLOW_GPIO_Port, &GPIO_InitStruct);

  GPIO_InitStruct.Pin = CALCULATE_Pin | CLEAR_Pin | SILVER_Pin;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
