#include "resistor_gui.h"
#include "ST7735.h"
#include "GFX_FUNCTIONS.h"
#include <string.h>
#include <stdio.h>

// Helper to draw a centered string
static void DrawCenteredString(uint16_t y, const char* str, FontDef font, uint16_t color, uint16_t bgcolor) {
    int len = strlen(str);
    int width = len * font.width;
    int x = (160 - width) / 2;
    if (x < 0) x = 0;
    ST7735_WriteString(x, y, str, font, color, bgcolor);
}

void GUI_Init(void) {
    // Initialize ST7735 display in flipped landscape mode (rotation = 3)
    ST7735_Init(3);
    // Clear screen to navy blue
    ST7735_FillScreen(BG_COLOR);
    // Draw initial empty resistor graphic
    GUI_DrawResistor(NULL, 0);
}

void GUI_DrawResistor(const ResistorColor* colors, int count) {
    // Redraw leads to cover any old bands
    // Left lead: x=15 to 48, y=38 to 42
    ST7735_FillRectangle(15, 38, 33, 5, RESISTOR_LEAD);
    // Right lead: x=112 to 145, y=38 to 42
    ST7735_FillRectangle(112, 38, 33, 5, RESISTOR_LEAD);

    // Redraw body bulbs and center
    // Left bulb: center=(48,40), r=13
    fillCircle(48, 40, 13, RESISTOR_BODY);
    // Right bulb: center=(112,40), r=13
    fillCircle(112, 40, 13, RESISTOR_BODY);
    // Middle cylinder: x=48 to 112, y=31 to 49
    ST7735_FillRectangle(48, 31, 64, 19, RESISTOR_BODY);

    if (colors == NULL || count == 0) {
        return;
    }

    // Band positions mapping depending on number of entered colors
    int x_pos[6] = {0};
    int band_width = 5;

    if (count <= 4) {
        // 3 or 4 bands: Digits at 50, 65. Multiplier at 80. Tolerance at 105.
        x_pos[0] = 50;
        x_pos[1] = 65;
        x_pos[2] = 80;
        x_pos[3] = 105;
    } else if (count == 5) {
        // 5 bands: Digits at 50, 62, 74. Multiplier at 86. Tolerance at 108.
        x_pos[0] = 50;
        x_pos[1] = 62;
        x_pos[2] = 74;
        x_pos[3] = 86;
        x_pos[4] = 108;
    } else if (count == 6) {
        // 6 bands: Digits at 50, 62, 74. Multiplier at 86. Tolerance at 102. Tempco at 112.
        x_pos[0] = 50;
        x_pos[1] = 62;
        x_pos[2] = 74;
        x_pos[3] = 86;
        x_pos[4] = 102;
        x_pos[5] = 112;
    }

    // Render each band on top of the bulging body shape
    for (int j = 0; j < count; j++) {
        ResistorColor col = colors[j];
        if (col == COLOR_NONE) continue;

        int start_x = x_pos[j];
        uint16_t c565 = GetColor565(col);

        for (int i = start_x; i < start_x + band_width; i++) {
            int y_start, h;
            // Bulbs lie outside [58, 102]. They have a taller height.
            if (i < 58 || i > 102) {
                y_start = 28;
                h = 25;
            } else {
                y_start = 31;
                h = 19;
            }
            ST7735_FillRectangle(i, y_start, 1, h, c565);
        }
    }
}

void GUI_DrawStatus(const char* status_msg) {
    // Clear text area (y = 75 to 128)
    ST7735_FillRectangle(0, 75, 160, 53, BG_COLOR);

    // Determine font based on string length
    if (strlen(status_msg) > 14) {
        DrawCenteredString(90, status_msg, Font_7x10, TEXT_COLOR, BG_COLOR);
    } else {
        DrawCenteredString(88, status_msg, Font_11x18, TEXT_COLOR, BG_COLOR);
    }
}

void GUI_DrawResult(const char* val_str, const char* tol_str) {
    // Clear text area (y = 75 to 128)
    ST7735_FillRectangle(0, 75, 160, 53, BG_COLOR);

    // Draw main value centered (Font_11x18)
    DrawCenteredString(80, val_str, Font_11x18, TEXT_COLOR, BG_COLOR);

    // Draw tolerance details centered below (Font_7x10)
    if (tol_str && strlen(tol_str) > 0) {
        DrawCenteredString(105, tol_str, Font_7x10, TEXT_COLOR, BG_COLOR);
    }
}

void GUI_DrawError(const char* err_title, const char* err_detail) {
    // Clear text area (y = 75 to 128)
    ST7735_FillRectangle(0, 75, 160, 53, BG_COLOR);

    // Draw "Error" title in RED (Font_11x18)
    DrawCenteredString(80, err_title, Font_11x18, RED, BG_COLOR);

    // Draw detail message below in RED (Font_7x10)
    if (err_detail) {
        DrawCenteredString(105, err_detail, Font_7x10, RED, BG_COLOR);
    }
}

#define LIME_GREEN      0x7FE0
#define HIGHLIGHT_BLUE  0x3DFF

static void DrawRectOutline(uint16_t x, uint16_t y, uint16_t w, uint16_t h, uint16_t color) {
    ST7735_FillRectangle(x, y, w, 2, color);             // Top
    ST7735_FillRectangle(x, y + h - 2, w, 2, color);     // Bottom
    ST7735_FillRectangle(x, y, 2, h, color);             // Left
    ST7735_FillRectangle(x + w - 2, y, 2, h, color);     // Right
}

void GUI_DrawMenu(uint8_t selection) {
    ST7735_FillScreen(BG_COLOR);

    // Draw choices
    DrawCenteredString(35, "COLOR MODE", Font_11x18, LIME_GREEN, BG_COLOR);
    DrawCenteredString(75, "VALUE MODE", Font_11x18, LIME_GREEN, BG_COLOR);

    // Draw highlight box
    if (selection == 0) {
        DrawRectOutline(18, 28, 124, 32, HIGHLIGHT_BLUE);
    } else {
        DrawRectOutline(18, 68, 124, 32, HIGHLIGHT_BLUE);
    }
}

void GUI_DrawTransition(uint8_t mode) {
    ST7735_FillScreen(BG_COLOR);

    DrawCenteredString(40, "CHANGING TO", Font_11x18, HIGHLIGHT_BLUE, BG_COLOR);
    if (mode == 0) {
        DrawCenteredString(70, "COLOR MODE", Font_11x18, HIGHLIGHT_BLUE, BG_COLOR);
    } else {
        DrawCenteredString(70, "VALUE MODE", Font_11x18, HIGHLIGHT_BLUE, BG_COLOR);
    }
}
