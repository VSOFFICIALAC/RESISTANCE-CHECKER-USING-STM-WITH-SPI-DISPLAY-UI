#include "resistor_calculator.h"
#include <stdio.h>
#include <string.h>

const char* GetColorAbbreviation(ResistorColor color) {
    switch (color) {
        case COLOR_BLACK:  return "BK";
        case COLOR_BROWN:  return "BR";
        case COLOR_RED:    return "RD";
        case COLOR_ORANGE: return "OR";
        case COLOR_YELLOW: return "YE";
        case COLOR_GREEN:  return "GN";
        case COLOR_BLUE:   return "BL";
        case COLOR_VIOLET: return "VI";
        case COLOR_GRAY:   return "GY";
        case COLOR_WHITE:  return "WH";
        case COLOR_GOLD:   return "GD";
        case COLOR_SILVER: return "SL";
        default:           return "--";
    }
}

uint16_t GetColor565(ResistorColor color) {
    switch (color) {
        case COLOR_BLACK:  return 0x0000; // Black
        case COLOR_BROWN:  return 0x8A22; // Brown
        case COLOR_RED:    return 0xF800; // Red
        case COLOR_ORANGE: return 0xFC00; // Orange
        case COLOR_YELLOW: return 0xFFE0; // Yellow
        case COLOR_GREEN:  return 0x07E0; // Green
        case COLOR_BLUE:   return 0x001F; // Blue
        case COLOR_VIOLET: return 0xB019; // Violet
        case COLOR_GRAY:   return 0x8410; // Gray
        case COLOR_WHITE:  return 0xFFFF; // White
        case COLOR_GOLD:   return 0xD566; // Gold
        case COLOR_SILVER: return 0xC618; // Silver
        default:           return 0x00AA; // Navy Blue (Background fallback)
    }
}

bool ValidateColorSequence(const ResistorColor* colors, int count, char* error_msg, int max_len) {
    if (count < 3) {
        snprintf(error_msg, max_len, "Min 3 Bands");
        return false;
    }
    if (count > 6) {
        snprintf(error_msg, max_len, "Max 6 Bands");
        return false;
    }

    // Band 1 cannot be Black, Gold, or Silver
    if (colors[0] == COLOR_BLACK) {
        snprintf(error_msg, max_len, "1st cannot be Black");
        return false;
    }
    if (colors[0] == COLOR_GOLD || colors[0] == COLOR_SILVER) {
        snprintf(error_msg, max_len, "1st cannot be Gd/Sl");
        return false;
    }

    // Band 2 cannot be Gold or Silver
    if (colors[1] == COLOR_GOLD || colors[1] == COLOR_SILVER) {
        snprintf(error_msg, max_len, "2nd cannot be Gd/Sl");
        return false;
    }

    if (count == 3) {
        // 3-band: Digits: 1, 2. Multiplier: 3. (Gold/Silver valid multipliers)
    } else if (count == 4) {
        // 4-band: Digits: 1, 2. Multiplier: 3. Tolerance: 4.
        ResistorColor tol_color = colors[3];
        if (tol_color != COLOR_BROWN && tol_color != COLOR_RED && tol_color != COLOR_GREEN &&
            tol_color != COLOR_BLUE && tol_color != COLOR_VIOLET && tol_color != COLOR_GRAY &&
            tol_color != COLOR_GOLD && tol_color != COLOR_SILVER) {
            snprintf(error_msg, max_len, "Invalid Tol Band");
            return false;
        }
    } else if (count == 5) {
        // 5-band: Digits: 1, 2, 3. Multiplier: 4. Tolerance: 5.
        if (colors[2] == COLOR_GOLD || colors[2] == COLOR_SILVER) {
            snprintf(error_msg, max_len, "3rd cannot be Gd/Sl");
            return false;
        }
        ResistorColor tol_color = colors[4];
        if (tol_color != COLOR_BROWN && tol_color != COLOR_RED && tol_color != COLOR_GREEN &&
            tol_color != COLOR_BLUE && tol_color != COLOR_VIOLET && tol_color != COLOR_GRAY &&
            tol_color != COLOR_GOLD && tol_color != COLOR_SILVER) {
            snprintf(error_msg, max_len, "Invalid Tol Band");
            return false;
        }
    } else if (count == 6) {
        // 6-band: Digits: 1, 2, 3. Multiplier: 4. Tolerance: 5. Tempco: 6.
        if (colors[2] == COLOR_GOLD || colors[2] == COLOR_SILVER) {
            snprintf(error_msg, max_len, "3rd cannot be Gd/Sl");
            return false;
        }
        ResistorColor tol_color = colors[4];
        if (tol_color != COLOR_BROWN && tol_color != COLOR_RED && tol_color != COLOR_GREEN &&
            tol_color != COLOR_BLUE && tol_color != COLOR_VIOLET && tol_color != COLOR_GRAY &&
            tol_color != COLOR_GOLD && tol_color != COLOR_SILVER) {
            snprintf(error_msg, max_len, "Invalid Tol Band");
            return false;
        }
        ResistorColor tc_color = colors[5];
        if (tc_color == COLOR_GOLD || tc_color == COLOR_SILVER || tc_color == COLOR_WHITE || tc_color == COLOR_NONE) {
            snprintf(error_msg, max_len, "Invalid Tempco");
            return false;
        }
    }

    return true;
}

bool CalculateResistor(const ResistorColor* colors, int count, ResistorResult* result) {
    if (count < 3 || count > 6) return false;

    double multiplier_vals[] = {
        1.0,          // Black
        10.0,         // Brown
        100.0,        // Red
        1000.0,       // Orange
        10000.0,      // Yellow
        100000.0,     // Green
        1000000.0,    // Blue
        10000000.0,   // Violet
        100000000.0,  // Gray
        1000000000.0, // White
        0.1,          // Gold
        0.01          // Silver
    };

    float tolerance_vals[] = {
        0.0f,   // Black
        1.0f,   // Brown (+/-1%)
        2.0f,   // Red (+/-2%)
        0.0f,   // Orange
        0.0f,   // Yellow
        0.5f,   // Green (+/-0.5%)
        0.25f,  // Blue (+/-0.25%)
        0.1f,   // Violet (+/-0.1%)
        0.05f,  // Gray (+/-0.05%)
        0.0f,   // White
        5.0f,   // Gold (+/-5%)
        10.0f   // Silver (+/-10%)
    };

    int tempco_vals[] = {
        250, // Black (250 ppm)
        100, // Brown (100 ppm)
        50,  // Red (50 ppm)
        15,  // Orange (15 ppm)
        25,  // Yellow (25 ppm)
        20,  // Green (20 ppm)
        10,  // Blue (10 ppm)
        5,   // Violet (5 ppm)
        1,   // Gray (1 ppm)
        0,   // White
        0,   // Gold
        0    // Silver
    };

    if (count == 3 || count == 4) {
        int d1 = (int)colors[0];
        int d2 = (int)colors[1];
        double mult = multiplier_vals[colors[2]];
        result->value = (d1 * 10 + d2) * mult;

        if (count == 4) {
            result->tolerance = tolerance_vals[colors[3]];
            result->has_tolerance = true;
        } else {
            result->tolerance = 20.0f; // 3-band has default 20% tolerance
            result->has_tolerance = true;
        }
        result->has_tempco = false;
        result->tempco = 0;
    } else { // 5-band or 6-band
        int d1 = (int)colors[0];
        int d2 = (int)colors[1];
        int d3 = (int)colors[2];
        double mult = multiplier_vals[colors[3]];
        result->value = (d1 * 100 + d2 * 10 + d3) * mult;

        result->tolerance = tolerance_vals[colors[4]];
        result->has_tolerance = true;

        if (count == 6) {
            result->tempco = tempco_vals[colors[5]];
            result->has_tempco = true;
        } else {
            result->tempco = 0;
            result->has_tempco = false;
        }
    }

    return true;
}

static void format_double_value(double val, char* buf, int buf_len, const char* suffix) {
    if (val >= 1e9) {
        double temp = val / 1e9;
        uint32_t integer_part = (uint32_t)temp;
        uint32_t fractional_part = (uint32_t)((temp - integer_part) * 100 + 0.5);
        if (fractional_part >= 100) { integer_part++; fractional_part -= 100; }
        if (fractional_part == 0) {
            snprintf(buf, buf_len, "%lu G %s", integer_part, suffix);
        } else if (fractional_part % 10 == 0) {
            snprintf(buf, buf_len, "%lu.%lu G %s", integer_part, fractional_part / 10, suffix);
        } else {
            snprintf(buf, buf_len, "%lu.%02lu G %s", integer_part, fractional_part, suffix);
        }
    } else if (val >= 1e6) {
        double temp = val / 1e6;
        uint32_t integer_part = (uint32_t)temp;
        uint32_t fractional_part = (uint32_t)((temp - integer_part) * 100 + 0.5);
        if (fractional_part >= 100) { integer_part++; fractional_part -= 100; }
        if (fractional_part == 0) {
            snprintf(buf, buf_len, "%lu M %s", integer_part, suffix);
        } else if (fractional_part % 10 == 0) {
            snprintf(buf, buf_len, "%lu.%lu M %s", integer_part, fractional_part / 10, suffix);
        } else {
            snprintf(buf, buf_len, "%lu.%02lu M %s", integer_part, fractional_part, suffix);
        }
    } else if (val >= 1e3) {
        double temp = val / 1e3;
        uint32_t integer_part = (uint32_t)temp;
        uint32_t fractional_part = (uint32_t)((temp - integer_part) * 100 + 0.5);
        if (fractional_part >= 100) { integer_part++; fractional_part -= 100; }
        if (fractional_part == 0) {
            snprintf(buf, buf_len, "%lu k %s", integer_part, suffix);
        } else if (fractional_part % 10 == 0) {
            snprintf(buf, buf_len, "%lu.%lu k %s", integer_part, fractional_part / 10, suffix);
        } else {
            snprintf(buf, buf_len, "%lu.%02lu k %s", integer_part, fractional_part, suffix);
        }
    } else {
        uint32_t integer_part = (uint32_t)val;
        uint32_t fractional_part = (uint32_t)((val - integer_part) * 100 + 0.5);
        if (fractional_part >= 100) { integer_part++; fractional_part -= 100; }
        if (fractional_part == 0) {
            snprintf(buf, buf_len, "%lu %s", integer_part, suffix);
        } else if (fractional_part % 10 == 0) {
            snprintf(buf, buf_len, "%lu.%lu %s", integer_part, fractional_part / 10, suffix);
        } else {
            snprintf(buf, buf_len, "%lu.%02lu %s", integer_part, fractional_part, suffix);
        }
    }
}

void FormatResistance(const ResistorResult* result, char* val_buf, int val_len, char* tol_buf, int tol_len) {
    char value_str[32];
    format_double_value(result->value, value_str, sizeof(value_str), "ohm");
    snprintf(val_buf, val_len, "R = %s", value_str);

    if (result->has_tolerance) {
        char tol_str[16];
        float tol = result->tolerance;
        uint32_t integer_tol = (uint32_t)tol;
        uint32_t fractional_tol = (uint32_t)((tol - integer_tol) * 100 + 0.5);
        if (fractional_tol >= 100) { integer_tol++; fractional_tol -= 100; }
        if (fractional_tol == 0) {
            snprintf(tol_str, sizeof(tol_str), "%lu%%", integer_tol);
        } else if (fractional_tol % 10 == 0) {
            snprintf(tol_str, sizeof(tol_str), "%lu.%lu%%", integer_tol, fractional_tol / 10);
        } else {
            snprintf(tol_str, sizeof(tol_str), "%lu.%02lu%%", integer_tol, fractional_tol);
        }

        if (result->has_tempco) {
            snprintf(tol_buf, tol_len, "Tol: +/- %s  %d ppm", tol_str, result->tempco);
        } else {
            snprintf(tol_buf, tol_len, "Tol: +/- %s", tol_str);
        }
    } else {
        if (result->has_tempco) {
            snprintf(tol_buf, tol_len, "%d ppm", result->tempco);
        } else {
            tol_buf[0] = '\0';
        }
    }
}

const char* GetColorShortName(ResistorColor color) {
    switch (color) {
        case COLOR_BLACK:  return "Blk";
        case COLOR_BROWN:  return "Brn";
        case COLOR_RED:    return "Red";
        case COLOR_ORANGE: return "Ora";
        case COLOR_YELLOW: return "Yel";
        case COLOR_GREEN:  return "Grn";
        case COLOR_BLUE:   return "Blu";
        case COLOR_VIOLET: return "Vio";
        case COLOR_GRAY:   return "Gry";
        case COLOR_WHITE:  return "Wht";
        case COLOR_GOLD:   return "Gld";
        case COLOR_SILVER: return "Slv";
        default:           return "";
    }
}

static bool parse_digits(const char* str, int len, double* val_out) {
    if (len <= 0) {
        *val_out = 0.0;
        return true;
    }
    double val = 0.0;
    for (int i = 0; i < len; i++) {
        if (str[i] >= '0' && str[i] <= '9') {
            val = val * 10.0 + (str[i] - '0');
        } else {
            return false;
        }
    }
    *val_out = val;
    return true;
}

bool ParseResistanceString(const char* str, double* val_out) {
    char clean[32];
    int len = 0;
    for (int i = 0; str[i] != '\0' && len < 31; i++) {
        if (str[i] != ' ') {
            clean[len++] = str[i];
        }
    }
    clean[len] = '\0';
    if (len == 0) return false;

    // Check if the last character is a unit suffix (e.g. "4.7k" or "470R")
    double multiplier = 1.0;
    char last = clean[len - 1];
    if (last == 'k' || last == 'K') {
        multiplier = 1000.0;
        len--;
        clean[len] = '\0';
    } else if (last == 'm' || last == 'M') {
        multiplier = 1000000.0;
        len--;
        clean[len] = '\0';
    } else if (last == 'r' || last == 'R') {
        multiplier = 1.0;
        len--;
        clean[len] = '\0';
    }

    if (len == 0) return false;

    // Find the position of unit/separator in the remaining string
    int pos = -1;
    char unit = '\0';
    for (int i = 0; i < len; i++) {
        char c = clean[i];
        if (c == 'k' || c == 'K') { pos = i; unit = 'k'; break; }
        if (c == 'm' || c == 'M') { pos = i; unit = 'M'; break; }
        if (c == 'r' || c == 'R') { pos = i; unit = 'R'; break; }
        if (c == '.') { pos = i; unit = '.'; break; }
    }

    double val = 0.0;
    if (pos != -1) {
        double left_val = 0.0;
        if (pos > 0) {
            if (!parse_digits(clean, pos, &left_val)) return false;
        }

        double right_val = 0.0;
        int right_len = len - (pos + 1);
        if (right_len > 0) {
            if (!parse_digits(clean + pos + 1, right_len, &right_val)) return false;
            double scale = 1.0;
            for (int i = 0; i < right_len; i++) scale *= 10.0;
            right_val = right_val / scale;
        }

        val = left_val + right_val;

        // Apply internal separator multiplier (e.g. for "4k7")
        if (unit == 'k') {
            val *= 1000.0;
        } else if (unit == 'M') {
            val *= 1000000.0;
        }
    } else {
        // Just digits
        if (!parse_digits(clean, len, &val)) return false;
    }

    // Apply the trailing unit multiplier
    val *= multiplier;

    *val_out = val;
    return true;
}

static double simple_round(double val) {
    if (val < 0.0) {
        return (double)((int)(val - 0.5));
    }
    return (double)((int)(val + 0.5));
}

bool ValueToColors(double val, ResistorColor* colors, int* count, int prefer_bands) {
    if (val <= 0.0) return false;

    // First try 4-band representation
    if (prefer_bands == 0 || prefer_bands == 4) {
        double temp4 = val;
        int exp4 = 0;
        if (temp4 >= 10.0) {
            while (temp4 >= 100.0) {
                temp4 /= 10.0;
                exp4++;
            }
        } else {
            while (temp4 < 10.0) {
                temp4 *= 10.0;
                exp4--;
            }
        }

        double sig4 = simple_round(temp4);
        double calc4 = sig4;
        if (exp4 >= 0) {
            for (int i = 0; i < exp4; i++) calc4 *= 10.0;
        } else {
            for (int i = 0; i < -exp4; i++) calc4 /= 10.0;
        }

        double diff4 = val > calc4 ? (val - calc4) : (calc4 - val);
        bool use_4band = (diff4 / val < 0.005); // 0.5% tolerance

        if (use_4band && exp4 >= -2 && exp4 <= 9) {
            int d = (int)sig4;
            colors[0] = (ResistorColor)(d / 10);
            colors[1] = (ResistorColor)(d % 10);
            if (exp4 == -1) colors[2] = COLOR_GOLD;
            else if (exp4 == -2) colors[2] = COLOR_SILVER;
            else colors[2] = (ResistorColor)exp4;
            colors[3] = COLOR_GOLD; // default to 5% tolerance
            *count = 4;
            return true;
        }
    }

    // Otherwise try 5-band representation
    if (prefer_bands == 0 || prefer_bands == 5) {
        double temp5 = val;
        int exp5 = 0;
        if (temp5 >= 100.0) {
            while (temp5 >= 1000.0) {
                temp5 /= 10.0;
                exp5++;
            }
        } else {
            while (temp5 < 100.0) {
                temp5 *= 10.0;
                exp5--;
            }
        }

        double sig5 = simple_round(temp5);
        double calc5 = sig5;
        if (exp5 >= 0) {
            for (int i = 0; i < exp5; i++) calc5 *= 10.0;
        } else {
            for (int i = 0; i < -exp5; i++) calc5 /= 10.0;
        }

        double diff5 = val > calc5 ? (val - calc5) : (calc5 - val);
        if (diff5 / val < 0.05 && exp5 >= -2 && exp5 <= 9) {
            int d = (int)sig5;
            colors[0] = (ResistorColor)(d / 100);
            colors[1] = (ResistorColor)((d / 10) % 10);
            colors[2] = (ResistorColor)(d % 10);
            if (exp5 == -1) colors[3] = COLOR_GOLD;
            else if (exp5 == -2) colors[3] = COLOR_SILVER;
            else colors[3] = (ResistorColor)exp5;
            colors[4] = COLOR_BROWN; // default to 1% tolerance for 5-band
            *count = 5;
            return true;
        }
    }

    return false;
}
