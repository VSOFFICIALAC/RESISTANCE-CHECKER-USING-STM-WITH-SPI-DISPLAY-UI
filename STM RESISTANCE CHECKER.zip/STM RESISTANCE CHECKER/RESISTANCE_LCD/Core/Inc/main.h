/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define BLACK_Pin GPIO_PIN_0
#define BLACK_GPIO_Port GPIOA
#define BROWN_Pin GPIO_PIN_1
#define BROWN_GPIO_Port GPIOA
#define RED_Pin GPIO_PIN_2
#define RED_GPIO_Port GPIOA
#define ORANGE_Pin GPIO_PIN_3
#define ORANGE_GPIO_Port GPIOA
#define CS_Pin GPIO_PIN_4
#define CS_GPIO_Port GPIOA
#define YELLOW_Pin GPIO_PIN_6
#define YELLOW_GPIO_Port GPIOA
#define GOLD_Pin GPIO_PIN_0
#define GOLD_GPIO_Port GPIOB
#define A0_Pin GPIO_PIN_1
#define A0_GPIO_Port GPIOB
#define RESET_Pin GPIO_PIN_10
#define RESET_GPIO_Port GPIOB
#define CALCULATE_Pin GPIO_PIN_12
#define CALCULATE_GPIO_Port GPIOB
#define CLEAR_Pin GPIO_PIN_13
#define CLEAR_GPIO_Port GPIOB
#define GREEN_Pin GPIO_PIN_8
#define GREEN_GPIO_Port GPIOA
#define BLUE_Pin GPIO_PIN_9
#define BLUE_GPIO_Port GPIOA
#define VIOLET_Pin GPIO_PIN_10
#define VIOLET_GPIO_Port GPIOA
#define GRAY_Pin GPIO_PIN_11
#define GRAY_GPIO_Port GPIOA
#define WHITE_Pin GPIO_PIN_12
#define WHITE_GPIO_Port GPIOA
#define SILVER_Pin GPIO_PIN_5
#define SILVER_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
