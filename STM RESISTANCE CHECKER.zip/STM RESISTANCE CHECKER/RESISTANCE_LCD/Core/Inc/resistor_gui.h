#ifndef __RESISTOR_GUI_H__
#define __RESISTOR_GUI_H__

#include "resistor_calculator.h"
#include <stdint.h>

// Colors
#define BG_COLOR        0x00AA // Navy Blue
#define RESISTOR_BODY   0xE79A // Tan / Beige
#define RESISTOR_LEAD   0xC618 // Silver / Gray
#define TEXT_COLOR      0xFFFF // White

// Initializes the GUI screen
void GUI_Init(void);

// Redraws the screen background, resistor body, leads, and active bands
void GUI_DrawResistor(const ResistorColor* colors, int count);

// Displays the current band entry text or status message (centered)
void GUI_DrawStatus(const char* status_msg);

// Displays the calculated resistance and tolerance/tempco (centered)
void GUI_DrawResult(const char* val_str, const char* tol_str);

// Draws a clear error message
void GUI_DrawError(const char* err_title, const char* err_detail);

// Draws the initial menu screen with selection
void GUI_DrawMenu(uint8_t selection);

// Draws the transition screen
void GUI_DrawTransition(uint8_t mode);

#endif // __RESISTOR_GUI_H__
