#ifndef __RESISTOR_CALCULATOR_H__
#define __RESISTOR_CALCULATOR_H__

#include <stdint.h>
#include <stdbool.h>

typedef enum {
    COLOR_BLACK = 0,
    COLOR_BROWN,
    COLOR_RED,
    COLOR_ORANGE,
    COLOR_YELLOW,
    COLOR_GREEN,
    COLOR_BLUE,
    COLOR_VIOLET,
    COLOR_GRAY,
    COLOR_WHITE,
    COLOR_GOLD,
    COLOR_SILVER,
    COLOR_NONE
} ResistorColor;

typedef struct {
    double value;
    float tolerance;
    int tempco; // ppm/K, 0 if N/A
    bool has_tolerance;
    bool has_tempco;
} ResistorResult;

// Returns the 2-letter abbreviation for a color
const char* GetColorAbbreviation(ResistorColor color);

// Returns the 16-bit 565 color value for ST7735 display
uint16_t GetColor565(ResistorColor color);

// Validates the entered colors. Returns true if valid, false otherwise.
// Populates error_msg if invalid.
bool ValidateColorSequence(const ResistorColor* colors, int count, char* error_msg, int max_len);

// Decodes the resistance value, tolerance, and tempco from the color sequence.
// Returns true on success, false on failure.
bool CalculateResistor(const ResistorColor* colors, int count, ResistorResult* result);

// Formats the resistance value, tolerance, and tempco into human readable strings.
void FormatResistance(const ResistorResult* result, char* val_buf, int val_len, char* tol_buf, int tol_len);

// Parses a resistance string (e.g. "4k7", "10M", "100R") into a double value.
bool ParseResistanceString(const char* str, double* val_out);

// Converts a resistance value into a sequence of colors.
// prefer_bands can be 0 (auto), 4 (force 4-band), or 5 (force 5-band)
bool ValueToColors(double val, ResistorColor* colors, int* count, int prefer_bands);

// Returns the 3-letter abbreviation for a color (e.g. "Blk", "Red", "Yel")
const char* GetColorShortName(ResistorColor color);

#endif // __RESISTOR_CALCULATOR_H__
